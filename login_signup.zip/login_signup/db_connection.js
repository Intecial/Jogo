const sqlite3 = require("sqlite3").verbose();

const db= new sqlite3.Database("jogo-app/src/jogoDB.db",sqlite3.OPEN_READWRITE, (err)=> {
    if (err) return console.error(err.message);
    console.log("connection successful");
});

let userid=1;
let donationid =1;
let sellerID =1;
let shopID = 1;
let prodID =1;

let ustbl = "CREATE TABLE IF NOT EXISTS user (userID INTEGER ,fname TEXT, lname TEXT, email TEXT, pwd TEXT, phone TEXT)"
let usdonation = "CREATE TABLE IF NOT EXISTS userDonation (userID INTEGER, donationID INTEGER"
let dontion = "CREATE TABLE IF NOT EXISTS donation(donationID INTEGER, money INTEGER"
let selltabl = "CREATE TABLE IF NOT EXISTS seller(sellerID INTEGER, fname TEXT, lname TEXT, shopID INTEGER, phone TEXT, pwd TEXT) "
let shp= "CREATE TABLE IF NOT EXISTS shop(shopID INTEGER, shopName TEXT)"
let shopprod = "CREATE TABLE IF NOT EXISTS shopProduct(shopID INTEGER, prodID INTEGER)"
let prod = "CREATE TABLE IF NOT EXISTS product(prodID INTEGER, prodDesc TEXT ,  prodName TEXT)"
db.run(ustbl);
db.run(usdonation);
db.run(dontion);
db.run(selltabl);
db.run(shp);
db.run(shopprod);
db.run(prod);

function insert_to_user (fname,lname,email,pwd,phone) {
    db.run(
    "INSERT INTO user (userid,fname,lname,email,pwd,phone)");
    userid+=1;
}
function insert_to_user_donation(userID){
    db.run(
        "INSERT INTO userDonation (userid,donationid)");
        donationid+=1;
}

// db.close((err)=> {
//     if (err) return console.error(err.message);
// });